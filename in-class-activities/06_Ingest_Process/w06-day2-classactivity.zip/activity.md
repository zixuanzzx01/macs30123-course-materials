# 6W Group Activity
<!--
Future iterations, if I have a full week: do one task in MapReduce pseudocode after introducing the framework and another thing in mrjob language; other possible tasks: Student name, GPA; top salaries; https://jblomo.github.io/pycon-mrjob/slides/MapReduce.html

Note that this takes around 50-60 minutes for students to complete on Zoom; might be closer to 30-45 minutes in-person
-->

Today, we're going to practice writing `mrjob` code.

In groups, you should address the following prompt. When you are done drafting your answer as a group, post it below with the names of your group members up at the top of the post.

Facebook stores a list of friends for each user (note that friends are bi-directional on Facebook. If I'm your friend, you're mine). One common processing request is the "You and Joe have 230 friends in common" feature: when you visit someone's profile, you see a list of friends that you have in common. Write an `mrjob` script that returns a list of common friends for every pair of Facebook users (i.e. the common friends of users A and B are [C, D]). The code doesn't need to run, but it should be close to a working solution. Assume the friends are stored in a text flat file as lines of "Person:List of Friends", like so:

```
A:B,C,D
B:A,C,D,E
C:A,B,D,E
D:A,B,C,E
E:B,C,D
```

The expected output for your `mrjob` script based on the text flat file above is:
```
["A","B"]       ["C","D"]
["A","C"]       ["B","D"]
["A","D"]       ["B","C"]
["B","C"]       ["E","D","A"]
["B","D"]       ["E","C","A"]
["B","E"]       ["C","D"]
["C","D"]       ["E","B","A"]
["C","E"]       ["B","D"]
["D","E"]       ["B","C"]
```

-------

**Possible Answer:**
```Python
from mrjob.job import MRJob

class CommonFriends(MRJob):
  def mapper(self, _, line):
    '''
    Mapper yields pairs of users (key), along with associated friends within
    a single list of friends (value). For instance, mapper(A:B,C,D) yields:
    [A, B], [B, C, D]
    [A, C], [B, C, D]
    [A, D], [B, C, D]
    '''
    # Extract user and their list of friends from the text file
    split_data = line.split(":")
    user = split_data[0]
    list_of_friends = split_data[1].split(",")

    # Set each pair of users as the "key" (sorted, to ensure [A,B] == [B,A])
    for friend in list_of_friends:
      pair_users = [user, friend]
      pair_users.sort()
      # Key: Pair of Users, Value: List of Associated Friends
      yield pair_users, list_of_friends


  def reducer(self, pair_users, lists_of_friends):
    '''
    Lists of friends (values) are grouped together by pairs of users (keys)
    automatically by mrjob. The reducer then yields the intersection of these
    lists (i.e. the friends that the two users have in common). For instance,
    mapper(A:B,C,D) and mapper(B:A,C,D,E) yield the following
    lists of friends for the pair [A,B]:
    [A, B], [B, C, D]
    [A, B], [A, C, D, E]
    Which are grouped together by their key:
    [A, B], [[B, C, D], [A, C, D, E]]
    The reducer then computes the intersection of the lists of friends
    between users A and B -- a list of their common friends:
    [A, B], [C, D]
    '''
    # Generate lists of friends for each user so we can eval. their intersection
    lof = [list for list in lists_of_friends]

    # Find and yield intersection of user pairs' friend lists
    common_friends = set(lof[0]).intersection(set(lof[1]))
    yield pair_users, common_friends

if __name__ == '__main__':
  CommonFriends.run()
```
Run on local terminal (with test data provided in the prompt):
```
python mr_activity.py mr_activity.txt
```
Output:
```
["A","B"]       ["C","D"]
["A","C"]       ["B","D"]
["A","D"]       ["B","C"]
["B","C"]       ["E","D","A"]
["B","D"]       ["E","C","A"]
["B","E"]       ["C","D"]
["C","D"]       ["E","B","A"]
["C","E"]       ["B","D"]
["D","E"]       ["B","C"]
```
