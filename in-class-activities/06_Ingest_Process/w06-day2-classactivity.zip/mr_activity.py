from mrjob.job import MRJob

class CommonFriends(MRJob):
  def mapper(self, _, line):
    '''
    Mapper yields pairs of users (key), along with common friends within
    a single list of friends (value). For instance, mapper(A:B,C,D) yields:
    [A, B], [B, C, D]
    [A, C], [B, C, D]
    [A, D], [B, C, D]
    '''
    # Extract user and their list of friends from the text file
    split_data = line.split(":")
    user = split_data[0]
    list_of_friends = split_data[1].split(",")

    # Set each pair of users as the "key" (sorted, to ensure [A,B] == [B,A])
    for friend in list_of_friends:
      pair_users = [user, friend]
      pair_users.sort()
      # Key: Pair of Users, Value: List of Friends
      yield pair_users, list_of_friends


  def reducer(self, pair_users, lists_of_friends):
    '''
    Lists of friends (values) are grouped together by pairs of users (keys)
    automatically by mrjob. The reducer then yields the intersection of these
    lists (i.e. the friends that the two users have in common). For instance,
    mapper(A:B,C,D) and mapper(B:A,C,D,E) yield the following
    lists of friends for the pair [A,B]:
    [A, B], [B, C, D]
    [A, B], [A, C, D, E]
    Which are grouped together by their key:
    [A, B], [[B, C, D], [A, C, D, E]]
    The reducer then computes the intersection of the lists of friends
    between users A and B -- a list of their common friends:
    [A, B], [C, D]
    '''
    # Generate lists of friends for each user so we can eval. their intersection
    lof = [lst for lst in lists_of_friends]

    # Find and yield intersection of user pairs' friend lists
    common_friends = set(lof[0]).intersection(set(lof[1]))
    yield pair_users, list(common_friends)

if __name__ == '__main__':
  CommonFriends.run()
